import json
from pathlib import Path
import subprocess
import sys
import unittest

SCRIPT = Path(__file__).resolve().parents[1] / "scripts/check-plan.py"
class PlanGuard(unittest.TestCase):
    def guard(self, actions):
        payload = {"resource_changes": [{"address": "example.resource", "change": {"actions": actions}}]}
        return subprocess.run([sys.executable, str(SCRIPT)], input=json.dumps(payload), text=True, capture_output=True)
    def test_updates_allowed(self):
        self.assertEqual(self.guard(["update"]).returncode, 0)
    def test_create_allowed(self):
        self.assertEqual(self.guard(["create"]).returncode, 0)
    def test_delete_blocked(self):
        self.assertNotEqual(self.guard(["delete"]).returncode, 0)
    def test_both_replacement_orders_blocked(self):
        for actions in [["create", "delete"], ["delete", "create"]]:
            self.assertNotEqual(self.guard(actions).returncode, 0)
