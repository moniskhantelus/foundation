import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

SOURCE = Path(__file__).resolve().parents[1] / 'scripts/backend.py'

class BackendWorkflow(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        (self.root / 'scripts').mkdir()
        self.script = self.root / 'scripts/backend.py'
        shutil.copyfile(SOURCE, self.script)
        for name in ['sandbox', 'dev']:
            (self.root / 'environments' / name).mkdir(parents=True)
        self.bin = self.root / 'bin'
        self.bin.mkdir()
        self.log = self.root / 'calls.jsonl'
        fake = self.bin / 'terraform'
        fake.write_text('#!' + sys.executable + '\n' + '''import json, os, sys
with open(os.environ['FAKE_LOG'], 'a') as f:
    f.write(json.dumps(sys.argv[1:]) + '\\n')
if 'output' in sys.argv:
    print(json.dumps(dict(resource_group_name='test-state-rg', storage_account_name='teststate', container_name='tfstate', key='foundation/sandbox.terraform.tfstate', environment='usgovernment', use_azuread_auth=True, subscription_id='test-subscription', tenant_id='test-tenant')))
''')
        fake.chmod(0o755)
        self.env = dict(os.environ, PATH=str(self.bin) + os.pathsep + os.environ['PATH'], FAKE_LOG=str(self.log), STATE_RESOURCE_GROUP='dev-state-rg', STATE_STORAGE_ACCOUNT='devstate', ARM_SUBSCRIPTION_ID='test-subscription', ARM_TENANT_ID='test-tenant')
    def run_helper(self, environment, mode):
        return subprocess.run([sys.executable, str(self.script), environment, mode], env=self.env, text=True, capture_output=True)
    def test_migration_preserves_state_and_uses_terraform(self):
        directory = self.root / 'environments/sandbox'
        state = directory / 'terraform.tfstate'
        state.write_text('local-state-fixture')
        result = self.run_helper('sandbox', 'migrate')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(state.read_text(), 'local-state-fixture')
        self.assertTrue((directory / 'backend.tf').exists())
        self.assertIn('foundation/sandbox.terraform.tfstate', (directory / 'backend.hcl').read_text())
        calls = [json.loads(line) for line in self.log.read_text().splitlines()]
        self.assertIn('-migrate-state', calls[-1])
        self.assertNotIn('-force-copy', calls[-1])
        self.assertNotIn('-reconfigure', calls[-1])
    def test_migration_refuses_missing_state(self):
        self.assertNotEqual(self.run_helper('sandbox', 'migrate').returncode, 0)
        self.assertFalse(self.log.exists())
    def test_migration_refuses_existing_backend(self):
        (self.root / 'environments/sandbox/backend.tf').write_text('existing')
        self.assertNotEqual(self.run_helper('sandbox', 'migrate').returncode, 0)
        self.assertFalse(self.log.exists())
    def test_remote_targets_only_selected_environment(self):
        result = self.run_helper('dev', 'remote')
        self.assertEqual(result.returncode, 0, result.stderr)
        config = (self.root / 'environments/dev/backend.hcl').read_text()
        self.assertIn('foundation/dev.terraform.tfstate', config)
        self.assertIn('usgovernment', config)
        self.assertIn('use_azuread_auth = true', config)
        self.assertFalse((self.root / 'environments/sandbox/backend.tf').exists())
        self.assertIn('-reconfigure', json.loads(self.log.read_text().splitlines()[-1]))
    def test_migration_rejects_cross_environment_key(self):
        (self.root / 'environments/dev/terraform.tfstate').write_text('fixture')
        result = self.run_helper('dev', 'migrate')
        self.assertNotEqual(result.returncode, 0)
        self.assertFalse((self.root / 'environments/dev/backend.tf').exists())
    def test_invalid_environment_rejected(self):
        self.assertNotEqual(self.run_helper('production', 'remote').returncode, 0)
        self.assertFalse(self.log.exists())
