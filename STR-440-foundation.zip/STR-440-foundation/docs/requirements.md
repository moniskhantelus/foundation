# Requirement coverage and decisions

The referenced uploaded story could not be accessed. This matrix covers the explicit user request only.

| Requirement | Implementation / decision |
| --- | --- |
| Azure Government sandbox/dev | Independent environment roots, Government provider and backend settings |
| Native resources now | Shared local module containing AzureRM resources only; no unapproved external modules |
| Two RGs | state and platform RG per environment |
| Private GZRS state | Standard StorageV2, GZRS, public access/shared keys disabled |
| Versioning, 30-day soft delete | Blob versioning and blob/container delete retention |
| Five containers | Exactly five enforced; proposed default names in tfvars examples |
| Lifecycle, no WORM | Only prior versions/snapshots age out; default 90 days; no immutability resources |
| Platform Key Vault | Private Standard vault, RBAC, purge protection, 90-day soft delete |
| Private endpoints and DNS | Blob/vault PE, Government DNS zones, links for supplied existing VNets |
| Secrets Officer | Supplied Entra object IDs scoped to platform vault |
| State role | Blob Data Contributor scoped to tfstate container |
| Deletion locks | CanNotDelete on each RG, created after initial children |
| Tags | Required business tags plus enforced environment/managed_by/story; taggable resources only |
| tfvars templates | Separate sandbox/dev examples; IDs/names deliberately placeholders |
| Backend bootstrap/migration | No initial backend block; same-state migration helper; no dual ownership |
| GitLab CI | Local validation, protected default-branch plan and manual saved-plan apply, per-env serialization |
| CODEOWNERS | Explicit placeholder requiring actual group before merge |
| Tests | Schema validation, mock security/negative tests, Python migration/plan guard tests |

## Inputs still requiring team confirmation

Actual story attachment; approved business tag vocabulary; exact container names and history retention; approved name prefixes/region; existing network IDs and DNS ownership; Azure policies/GZRS availability; principal IDs and permission boundaries; CI image, runner, federation and GitLab approval settings; CODEOWNERS group; approved Boeing module URLs, immutable tags and migration constraints. None of these are evidence that resources exist.

No secrets, network foundation, subscriptions, Entra applications/groups, federated identity registration, or Azure diagnostic destinations are created. These are prerequisites or separate scope. Encryption uses Azure platform-managed keys; customer-managed keys are not asserted as a story requirement.
