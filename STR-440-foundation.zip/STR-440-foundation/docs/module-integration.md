# Integrating approved modules later

Native resource addresses live under `module.foundation`. Keep this package usable while source URLs and release tags are pending. Do not add a speculative Boeing URL or mutable branch reference.

When approvals arrive, inspect module resource names/inputs/outputs, required providers, Azure Government support, networking behavior and protective settings. Pin each Git source to the approved immutable release tag (or approved commit). Map every existing resource address to its new address using reviewed `moved` blocks when resource types match. If import is required, back up state and use reviewed import blocks; do not maintain duplicate state owners. Preserve both environment backend keys and state lineage.

Test against an isolated nonproduction state first; run mock tests and real authenticated plans. Require no unexpected creates, replacements or deletes, and verify GZRS/versioning/retention, private DNS suffixes, Entra auth, RBAC scopes and locks. Move locks with their resources; do not drop protection merely to make a module plan succeed. Update root outputs used by backend generation without altering their contract. Obtain team review before removing native declarations or changing ownership.
