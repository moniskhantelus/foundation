# Bootstrap, migration and operations

## Prerequisites

Use a secured workstation or private GitLab runner with outbound access to Azure Government ARM/Entra and the Terraform provider registry/mirror. It needs routing to the existing PE subnet and DNS resolution through Azure DNS or an approved private DNS resolver. The VNet containing that subnet must be in `virtual_network_ids`. Add runner VNet links as appropriate; links do not create peering, routes, VPNs or DNS forwarding. Existing custom DNS requires forwarding configured by the networking team. No VNet or subnet is created here.

Supply a dedicated PE-capable subnet with available IPs; check subnet policies, NSGs and UDRs before deployment. The selected Government region/subscription must support GZRS, private endpoints and required service SKUs; no silent LRS fallback is provided. Confirm both global storage and vault name availability. DNS zones are owned here: if equivalent zones/links already exist, coordinate import/ownership before apply rather than create conflicting authorities.

Pre-register Microsoft.Storage, Microsoft.KeyVault and Microsoft.Network in the deployment subscription. Provider automatic registration is disabled intentionally. Do not grant ongoing subscription-wide registration rights solely for this configuration.

The bootstrap identity needs Contributor-equivalent resource permissions in both RGs (and RG creation rights at subscription level), permission to create/remove management locks, role assignment write rights (e.g. a suitable RBAC administrator), subnet join permissions and VNet link permissions on supplied networking resources. Contributor alone cannot assign RBAC. Assign the deployment identity appropriate scoped roles before bootstrap. Creating DNS links across subscriptions requires permissions on both sides and tested provider/subscription access.

Backend identities need Storage Blob Data Contributor on the `tfstate` container. The module creates these assignments from supplied object IDs. Management-plane provider operations and lock/role management need their own rights; the backend role alone cannot manage infrastructure. Private container creation using `storage_account_id` uses the current AzureRM ARM path; any data-plane operation still requires network and data-plane authorization. Do not temporarily enable public access/shared keys to work around a 403. If policy/provider behavior requires bootstrap data-plane access, have an authorized administrator assign the narrowly scoped storage data role externally, then import/manage it deliberately to avoid duplicate assignments.

## Authentication

For interactive Azure CLI authentication (CLI installed separately):

```bash
az cloud set --name AzureUSGovernment
az login --tenant "$ARM_TENANT_ID"
az account set --subscription "$ARM_SUBSCRIPTION_ID"
export ARM_ENVIRONMENT=usgovernment
export ARM_USE_AZUREAD=true
```

Export IDs from approved configuration; do not paste credentials into source. For GitLab use federation as described in README. The provider and backend both select `usgovernment`. Never mix public cloud CLI context with Government resources.

## 1. Prepare sandbox (repeat independently for dev)

```bash
cp environments/sandbox/environment.tfvars.example environments/sandbox/environment.tfvars
# Edit the copy. Confirm environment=sandbox and replace every placeholder.
terraform -chdir=environments/sandbox init
terraform -chdir=environments/sandbox validate
terraform -chdir=environments/sandbox plan -var-file=environment.tfvars -out=bootstrap.tfplan
terraform -chdir=environments/sandbox show bootstrap.tfplan
```

There must be no `backend.tf` or old `.terraform` backend metadata in a fresh bootstrap directory. A clean package has neither. Do not use `init -backend=false` to pretend an existing remote-backend configuration uses local state; that flag only skips backend initialization. Review subscription, tenant, RG names, two endpoints, five containers, RBAC and locks. Protect local state and plans using filesystem permissions and approved encrypted storage. Terraform state is sensitive even when no secrets are intentionally managed.

## 2. Apply local bootstrap

```bash
terraform -chdir=environments/sandbox apply bootstrap.tfplan
terraform -chdir=environments/sandbox output backend_config
```

Apply may require RBAC propagation time before data-plane access works. Retry after diagnosing authorization/DNS, without changing private access. Endpoints/DNS dependencies order provisioning, but do not prove DNS propagation. If apply fails partway, retain local state, inspect the failure and re-plan from the same directory. Do not create a second state or import blindly. Locks are installed last and may block later replacements; routine changes are expected to be nondestructive.

## 3. Verify private access before migration

From the same workstation/runner, verify storage's normal FQDN resolves via the private link chain to the endpoint's private IP and is reachable over HTTPS. Verify the vault's normal FQDN similarly. Use normal service hostnames, not raw IPs. Confirm the bootstrap identity is in `state_blob_contributor_principal_ids` or has equivalent temporary approved backend rights; allow propagation. A private DNS link alone does not prove connectivity.

## 4. Migrate the existing local state

```bash
python3 scripts/backend.py sandbox migrate
```

The helper reads only the explicit nonsecret `backend_config` output from the local state, writes ignored `backend.hcl` and `backend.tf`, then runs `terraform init -migrate-state`. Review Terraform's prompt and confirm copying the existing state to the newly created backend. It never runs apply, force-copy or deletes local state. If Terraform reports existing destination state, stop and compare ownership/lineage instead of overwriting. Same operation for dev uses `python3 scripts/backend.py dev migrate` from its independent local bootstrap.

```bash
terraform -chdir=environments/sandbox state list
terraform -chdir=environments/sandbox plan -var-file=environment.tfvars -detailed-exitcode
```

Exit code 0 is the target no-change result; 2 means changes need review, 1 means error. Check backend blob existence/versioning using approved storage tools and compare pre/post resource addresses and state lineage securely. Do not log raw state. Only after confirming remote ownership and an independent secure backup should you remove obsolete local state/plan copies per retention policy. Never delete the backend blob as cleanup.

## 5. Subsequent clean checkout / CI

Remote initialization takes nonsecret values from environment-scoped `STATE_RESOURCE_GROUP`, `STATE_STORAGE_ACCOUNT`, `ARM_SUBSCRIPTION_ID` and `ARM_TENANT_ID`. The helper derives the fixed environment key and Government/Entra settings:

```bash
python3 scripts/backend.py sandbox remote
terraform -chdir=environments/sandbox plan -var-file=environment.tfvars -out=foundation.tfplan
terraform -chdir=environments/sandbox apply foundation.tfplan
```

Only use `remote` once migration has succeeded; remote init can otherwise select an empty backend and produce a duplicate-create plan. Confirm `state list` contains the expected resources before planning from a new checkout. Keep backend config consistent with the environment. The environment root rejects another environment value, but IDs must still be reviewed.

## Recovery

- Interrupted migration: retain local state and backup, inspect whether the destination contains the correct lineage, then rerun `terraform init -migrate-state -backend-config=backend.hcl` in that same environment. The helper refuses to overwrite an existing backend declaration in migration mode.
- Lost lease: first prove no active Terraform operation owns it; use `force-unlock` only under team incident procedure. Do not disable state locking.
- State corruption/deletion: stop writers, preserve current blob/version evidence, restore an approved prior blob version or soft-deleted blob through authorized storage tools, then review state lineage and plan before writing. GZRS is asynchronous replication and is not a point-in-time state backup guarantee. Rehearse recovery separately.
- DNS or 403 failure: check tenant/cloud, private resolution, routes, identity object IDs, scoped roles and propagation. CI federation audience/subject must exactly match the tenant registration.

## Teardown

No destroy job is supplied. Both RG locks protect child resources; intentional replacement/deletion needs explicit review and coordinated temporary lock removal. A Terraform destroy may remove locks because they are Terraform-managed, so Azure locks do not replace approval/access controls. The CI guard rejects deletes and replacements in normal plans.

Move this foundation's state to a separate surviving backend or secured local state under an approved change before deleting its own backend. Preserve required backups, remove locks under that change, and inspect a separate destroy plan. Key Vault purge protection remains effective for its 90-day retention and cannot be bypassed by disabling a setting. Do not force purge or promise immediate name reuse.
