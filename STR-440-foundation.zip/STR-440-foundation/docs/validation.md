# Validation and acceptance

## Local checks (no deployment)

```bash
bash scripts/validate.sh
```

This runs recursive format checks, provider initialization, validate for shared module and both roots, mocked Terraform tests and Python unit tests. Mock tests validate Terraform behavior and configuration assertions without Azure credentials. They do not prove cloud permissions, private connectivity, regional availability, GZRS replication, Azure Policy compliance or actual deployment. Test-only UUIDs/ARM IDs are synthetic fixtures, not deployment identifiers.

For an individual check:

```bash
terraform -chdir=modules/foundation init -backend=false
terraform -chdir=modules/foundation test
python3 -m unittest discover -s tests -v
```

If a private registry/mirror is used, configure it through approved Terraform CLI configuration outside source. Keep lock files in version control. Provider initialization needs package network access; mock mode still needs the provider binary/schema.

## Azure acceptance (not executed for this package)

After filling inputs and satisfying bootstrap prerequisites:

1. Review an authenticated saved plan for each environment independently. Check subscription/tenant, region GZRS support, five expected private containers, exactly two RGs and two PEs. Apply only the approved saved plan.
2. Verify storage settings through Azure ARM: GZRS, shared keys/public access off, TLS 1.2, versioning on, both soft-delete periods 30 days. Verify lifecycle has only historical version/snapshot expiration and no live blob delete/tiering or immutability.
3. Verify vault RBAC/public access/purge protection/90-day retention; check Secrets Officer assignments by object ID and scope. Verify state contributors are scoped to tfstate. Use only disposable nonsecret test content if testing data operations.
4. From an authorized private runner, resolve normal blob/vault hostnames to the intended PE private addresses and perform authenticated data operations. From a public network without private routing, data access must fail even for an otherwise authorized identity. Do not temporarily enable public access.
5. Verify both RG CanNotDelete locks and tags; test deletion denial only on a separately approved disposable resource, never the actual state account. Locks must not be mistaken for protection against an identity authorized to remove them.
6. Migrate local state, confirm remote state ownership and obtain a no-change plan. Reinitialize from a clean checkout and confirm the same resource addresses. Run dev separately and verify distinct account, vault, RG names and state key.
7. Exercise GitLab federation, serialized plans and manual saved-plan apply. Check unauthorized branches cannot obtain cloud jobs/variables, plan artifacts are restricted, and deletion/replacement plans fail the guard.
8. Rehearse blob version recovery and interrupted migration in an isolated test foundation; record evidence in the change request. Do not run recovery experiments against the active state blob.

Use exit code 0 from `plan -detailed-exitcode` as no drift, 2 as changes needing review, 1 as failure. Retain only approved evidence and redact sensitive identifiers according to local policy.
