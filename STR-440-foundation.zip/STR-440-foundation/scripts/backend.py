#!/usr/bin/env python3
"""Prepare nonsecret backend config. Never copies or rewrites Terraform state."""
import argparse
import json
import os
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("environment", choices=["sandbox", "dev"])
parser.add_argument("mode", choices=["migrate", "remote"])
a = parser.parse_args()
directory = root / "environments" / a.environment
backend = directory / "backend.tf"
config = directory / "backend.hcl"
if a.mode == "migrate":
    if backend.exists():
        raise SystemExit("backend.tf already exists. Inspect init status; retry terraform init -migrate-state manually if migration was interrupted.")
    if not (directory / "terraform.tfstate").exists():
        raise SystemExit("No local bootstrap state found. Do not migrate an empty state.")
    result = subprocess.run(["terraform", f"-chdir={directory}", "output", "-json", "backend_config"], check=True, capture_output=True, text=True)
    data = json.loads(result.stdout)
else:
    names = {"resource_group_name": "STATE_RESOURCE_GROUP", "storage_account_name": "STATE_STORAGE_ACCOUNT", "subscription_id": "ARM_SUBSCRIPTION_ID", "tenant_id": "ARM_TENANT_ID"}
    data = {key: os.environ[name] for key, name in names.items()}
    data.update(container_name="tfstate", key=f"foundation/{a.environment}.terraform.tfstate", environment="usgovernment", use_azuread_auth=True)
expected = f"foundation/{a.environment}.terraform.tfstate"
if data["key"] != expected or data["environment"] != "usgovernment":
    raise SystemExit("Environment/backend mismatch")
# JSON quoting is HCL-compatible; only explicit nonsecret fields are accepted.
fields = ["resource_group_name", "storage_account_name", "container_name", "key", "environment", "use_azuread_auth", "subscription_id", "tenant_id"]
config.write_text("".join(f"{key} = {json.dumps(data[key])}\n" for key in fields))
backend.write_text('terraform {\n  backend "azurerm" {}\n}\n')
if a.mode == "migrate":
    # Terraform prompts for confirmation; preserve local state and backups until verified.
    subprocess.run(["terraform", f"-chdir={directory}", "init", "-migrate-state", f"-backend-config={config}"], check=True)
else:
    subprocess.run(["terraform", f"-chdir={directory}", "init", "-reconfigure", "-input=false", f"-backend-config={config}"], check=True)
