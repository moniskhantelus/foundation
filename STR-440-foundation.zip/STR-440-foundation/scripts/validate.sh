#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
terraform fmt -check -recursive
for directory in modules/foundation environments/sandbox environments/dev; do
  terraform -chdir="$directory" init -backend=false -input=false
  terraform -chdir="$directory" validate
 done
terraform -chdir=modules/foundation test
python3 -m unittest discover -s tests -v
