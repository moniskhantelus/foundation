#!/usr/bin/env python3
"""Reject deletes/replacements in routine CI; approved teardown is a separate operation."""
import json
import sys
plan = json.load(sys.stdin)
violations = [r["address"] for r in plan.get("resource_changes", []) if "delete" in r["change"]["actions"]]
if violations:
    raise SystemExit("Blocked deletion/replacement: " + ", ".join(violations))
print("Plan contains no deletions or replacements.")
