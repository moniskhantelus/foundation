variable "environment" {
  type = string
  validation {
    condition     = var.environment == "dev"
    error_message = "This directory only accepts environment dev."
  }
}
variable "subscription_id" { type = string }
variable "tenant_id" { type = string }
variable "location" {
  type    = string
  default = "usgovvirginia"
}
variable "prefix" {
  type = string
  validation {
    condition     = can(regex("^[a-z][a-z0-9-]{1,19}$", var.prefix))
    error_message = "Prefix must be 2-20 lowercase letters, digits or hyphens, starting with a letter."
  }
}
variable "storage_account_name" {
  type = string
  validation {
    condition     = can(regex("^[a-z0-9]{3,24}$", var.storage_account_name))
    error_message = "Storage name must be 3-24 lowercase alphanumeric characters and globally unique."
  }
}
variable "key_vault_name" {
  type = string
  validation {
    condition     = can(regex("^[a-zA-Z][a-zA-Z0-9-]{1,22}[a-zA-Z0-9]$", var.key_vault_name)) && !strcontains(var.key_vault_name, "--")
    error_message = "Key Vault name must be 3-24 characters, start with a letter and contain no consecutive hyphens."
  }
}
variable "private_endpoint_subnet_id" {
  type        = string
  description = "Existing, reachable private endpoint subnet; configure subnet PE policies and address capacity externally."
}
variable "virtual_network_ids" {
  type        = map(string)
  description = "Stable link names mapped to existing VNet ARM IDs, including the PE VNet and runner resolution VNet."
  validation {
    condition     = length(var.virtual_network_ids) > 0
    error_message = "At least one VNet must be linked."
  }
}
variable "secrets_officer_principal_ids" {
  type        = set(string)
  description = "Entra object IDs of groups or service principals, never application/client IDs."
  validation {
    condition     = length(var.secrets_officer_principal_ids) > 0
    error_message = "Specify at least one Secrets Officer principal."
  }
}
variable "state_blob_contributor_principal_ids" {
  type        = set(string)
  description = "Entra object IDs of backend users/CI identities; grants blob access only to the tfstate container."
  validation {
    condition     = length(var.state_blob_contributor_principal_ids) > 0
    error_message = "Specify at least one state access principal."
  }
}
variable "container_names" {
  type    = set(string)
  default = ["tfstate", "artifacts", "logs", "backups", "bootstrap"]
  validation {
    condition     = length(var.container_names) == 5 && contains(var.container_names, "tfstate") && alltrue([for n in var.container_names : can(regex("^[a-z0-9][a-z0-9-]{1,61}[a-z0-9]$", n)) && !strcontains(n, "--")])
    error_message = "Provide exactly five valid private container names including tfstate."
  }
}
variable "history_retention_days" {
  type    = number
  default = 90
  validation {
    condition     = var.history_retention_days >= 31 && floor(var.history_retention_days) == var.history_retention_days
    error_message = "History retention must be an integer of at least 31 days."
  }
}
variable "tags" {
  type        = map(string)
  description = "Required business tags; organization-specific tag keys can be added."
  validation {
    condition     = alltrue([for k in ["owner", "cost_center", "application", "data_classification"] : try(length(trimspace(var.tags[k])) > 0, false)])
    error_message = "Nonempty owner, cost_center, application and data_classification tags are required."
  }
}
