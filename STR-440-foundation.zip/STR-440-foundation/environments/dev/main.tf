provider "azurerm" {
  features {
    key_vault { purge_soft_delete_on_destroy = false }
  }
  environment                     = "usgovernment"
  subscription_id                 = var.subscription_id
  tenant_id                       = var.tenant_id
  storage_use_azuread             = true
  resource_provider_registrations = "none"
}
module "foundation" {
  source                               = "../../modules/foundation"
  environment                          = var.environment
  subscription_id                      = var.subscription_id
  tenant_id                            = var.tenant_id
  location                             = var.location
  prefix                               = var.prefix
  storage_account_name                 = var.storage_account_name
  key_vault_name                       = var.key_vault_name
  private_endpoint_subnet_id           = var.private_endpoint_subnet_id
  virtual_network_ids                  = var.virtual_network_ids
  secrets_officer_principal_ids        = var.secrets_officer_principal_ids
  state_blob_contributor_principal_ids = var.state_blob_contributor_principal_ids
  container_names                      = var.container_names
  history_retention_days               = var.history_retention_days
  tags                                 = var.tags
}
output "backend_config" { value = module.foundation.backend_config }
output "key_vault_id" { value = module.foundation.key_vault_id }
output "resource_group_ids" { value = module.foundation.resource_group_ids }
