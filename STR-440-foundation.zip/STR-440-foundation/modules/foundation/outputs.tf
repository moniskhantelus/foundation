output "backend_config" {
  value = {
    resource_group_name  = azurerm_resource_group.state.name
    storage_account_name = azurerm_storage_account.state.name
    container_name       = "tfstate"
    key                  = "foundation/${var.environment}.terraform.tfstate"
    environment          = "usgovernment"
    use_azuread_auth     = true
    subscription_id      = var.subscription_id
    tenant_id            = var.tenant_id
  }
}
output "resource_group_ids" { value = { state = azurerm_resource_group.state.id, platform = azurerm_resource_group.platform.id } }
output "key_vault_id" { value = azurerm_key_vault.platform.id }
output "storage_account_id" { value = azurerm_storage_account.state.id }
output "private_endpoint_ids" { value = { for k, v in azurerm_private_endpoint.this : k => v.id } }
