locals {
  name = "${var.prefix}-${var.environment}"
  tags = merge(var.tags, { environment = var.environment, managed_by = "terraform", story = "STR-440" })
  zones = {
    blob  = "privatelink.blob.core.usgovcloudapi.net"
    vault = "privatelink.vaultcore.usgovcloudapi.net"
  }
  links = { for pair in setproduct(keys(local.zones), keys(var.virtual_network_ids)) : "${pair[0]}-${pair[1]}" => { zone = pair[0], vnet = pair[1] } }
}
resource "azurerm_resource_group" "state" {
  name     = "${local.name}-state-rg"
  location = var.location
  tags     = local.tags
}
resource "azurerm_resource_group" "platform" {
  name     = "${local.name}-platform-rg"
  location = var.location
  tags     = local.tags
}
resource "azurerm_storage_account" "state" {
  name                             = var.storage_account_name
  resource_group_name              = azurerm_resource_group.state.name
  location                         = azurerm_resource_group.state.location
  account_kind                     = "StorageV2"
  account_tier                     = "Standard"
  account_replication_type         = "GZRS"
  min_tls_version                  = "TLS1_2"
  https_traffic_only_enabled       = true
  public_network_access_enabled    = false
  allow_nested_items_to_be_public  = false
  shared_access_key_enabled        = false
  default_to_oauth_authentication  = true
  cross_tenant_replication_enabled = false
  network_rules {
    default_action = "Deny"
    bypass         = ["None"]
  }
  blob_properties {
    versioning_enabled = true
    delete_retention_policy { days = 30 }
    container_delete_retention_policy { days = 30 }
  }
  tags = local.tags
}
resource "azurerm_storage_container" "this" {
  for_each              = var.container_names
  name                  = each.value
  storage_account_id    = azurerm_storage_account.state.id
  container_access_type = "private"
  depends_on            = [azurerm_private_endpoint.this, azurerm_private_dns_zone_virtual_network_link.this]
}
# Never delete or tier the live state blob. Only old versions and snapshots expire.
resource "azurerm_storage_management_policy" "history" {
  storage_account_id = azurerm_storage_account.state.id
  rule {
    name    = "expire-old-history"
    enabled = true
    filters { blob_types = ["blockBlob"] }
    actions {
      version { delete_after_days_since_creation = var.history_retention_days }
      snapshot { delete_after_days_since_creation_greater_than = var.history_retention_days }
    }
  }
}
resource "azurerm_key_vault" "platform" {
  name                          = var.key_vault_name
  resource_group_name           = azurerm_resource_group.platform.name
  location                      = azurerm_resource_group.platform.location
  tenant_id                     = var.tenant_id
  sku_name                      = "standard"
  rbac_authorization_enabled    = true
  purge_protection_enabled      = true
  soft_delete_retention_days    = 90
  public_network_access_enabled = false
  network_acls {
    bypass         = "None"
    default_action = "Deny"
  }
  tags = local.tags
}
resource "azurerm_private_dns_zone" "this" {
  for_each            = local.zones
  name                = each.value
  resource_group_name = azurerm_resource_group.platform.name
  tags                = local.tags
}
resource "azurerm_private_dns_zone_virtual_network_link" "this" {
  for_each              = local.links
  name                  = "${local.name}-${each.key}"
  resource_group_name   = azurerm_resource_group.platform.name
  private_dns_zone_name = azurerm_private_dns_zone.this[each.value.zone].name
  virtual_network_id    = var.virtual_network_ids[each.value.vnet]
  registration_enabled  = false
  tags                  = local.tags
}
resource "azurerm_private_endpoint" "this" {
  for_each            = local.zones
  name                = "${local.name}-${each.key}-pe"
  location            = var.location
  resource_group_name = azurerm_resource_group.platform.name
  subnet_id           = var.private_endpoint_subnet_id
  private_service_connection {
    name                           = "${local.name}-${each.key}-psc"
    private_connection_resource_id = each.key == "blob" ? azurerm_storage_account.state.id : azurerm_key_vault.platform.id
    subresource_names              = [each.key]
    is_manual_connection           = false
  }
  private_dns_zone_group {
    name                 = "default"
    private_dns_zone_ids = [azurerm_private_dns_zone.this[each.key].id]
  }
  tags = local.tags
}
resource "azurerm_role_assignment" "secrets_officer" {
  for_each             = var.secrets_officer_principal_ids
  scope                = azurerm_key_vault.platform.id
  role_definition_name = "Key Vault Secrets Officer"
  principal_id         = each.value
}
resource "azurerm_role_assignment" "state_access" {
  for_each             = var.state_blob_contributor_principal_ids
  scope                = azurerm_storage_container.this["tfstate"].id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = each.value
}
# RG locks inherit to children. Create after all initial resources to avoid bootstrap races.
resource "azurerm_management_lock" "state" {
  name       = "${local.name}-state-delete-lock"
  scope      = azurerm_resource_group.state.id
  lock_level = "CanNotDelete"
  notes      = "Protect STR-440 state foundation. Remove only through an approved teardown."
  depends_on = [azurerm_storage_container.this, azurerm_storage_management_policy.history, azurerm_role_assignment.state_access]
}
resource "azurerm_management_lock" "platform" {
  name       = "${local.name}-platform-delete-lock"
  scope      = azurerm_resource_group.platform.id
  lock_level = "CanNotDelete"
  notes      = "Protect STR-440 platform foundation. Remove only through an approved teardown."
  depends_on = [azurerm_private_endpoint.this, azurerm_private_dns_zone_virtual_network_link.this, azurerm_role_assignment.secrets_officer]
}
