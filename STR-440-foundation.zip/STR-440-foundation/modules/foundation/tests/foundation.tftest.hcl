mock_provider "azurerm" {}

variables {
  environment                          = "sandbox"
  subscription_id                      = "00000000-0000-0000-0000-000000000001"
  tenant_id                            = "00000000-0000-0000-0000-000000000002"
  prefix                               = "test"
  storage_account_name                 = "str440teststate"
  key_vault_name                       = "str440-test-kv"
  private_endpoint_subnet_id           = "/subscriptions/00000000-0000-0000-0000-000000000001/resourceGroups/network/providers/Microsoft.Network/virtualNetworks/test/subnets/private"
  virtual_network_ids                  = { test = "/subscriptions/00000000-0000-0000-0000-000000000001/resourceGroups/network/providers/Microsoft.Network/virtualNetworks/test" }
  secrets_officer_principal_ids        = ["00000000-0000-0000-0000-000000000003"]
  state_blob_contributor_principal_ids = ["00000000-0000-0000-0000-000000000004"]
  tags                                 = { owner = "test", cost_center = "test", application = "foundation", data_classification = "test" }
}
# Supply realistic ARM IDs where downstream AzureRM parsing needs them.
override_resource {
  target = azurerm_storage_account.state
  values = { id = "/subscriptions/00000000-0000-0000-0000-000000000001/resourceGroups/test/providers/Microsoft.Storage/storageAccounts/str440teststate" }
}
override_resource {
  target = azurerm_key_vault.platform
  values = { id = "/subscriptions/00000000-0000-0000-0000-000000000001/resourceGroups/test/providers/Microsoft.KeyVault/vaults/str440-test-kv" }
}
override_resource {
  target = azurerm_resource_group.state
  values = { id = "/subscriptions/00000000-0000-0000-0000-000000000001/resourceGroups/test-state" }
}
override_resource {
  target = azurerm_resource_group.platform
  values = { id = "/subscriptions/00000000-0000-0000-0000-000000000001/resourceGroups/test-platform" }
}
run "foundation_security" {
  command = plan
  assert {
    condition     = azurerm_storage_account.state.account_replication_type == "GZRS" && !azurerm_storage_account.state.public_network_access_enabled && !azurerm_storage_account.state.shared_access_key_enabled
    error_message = "State storage must remain GZRS, private and Entra-only."
  }
  assert {
    condition     = azurerm_storage_account.state.blob_properties[0].versioning_enabled && azurerm_storage_account.state.blob_properties[0].delete_retention_policy[0].days == 30 && azurerm_storage_account.state.blob_properties[0].container_delete_retention_policy[0].days == 30
    error_message = "Versioning and both 30-day soft delete policies required."
  }
  assert {
    condition     = length(azurerm_storage_container.this) == 5 && alltrue([for c in azurerm_storage_container.this : c.container_access_type == "private"])
    error_message = "Exactly five private containers required."
  }
  assert {
    condition     = azurerm_key_vault.platform.rbac_authorization_enabled && azurerm_key_vault.platform.purge_protection_enabled && !azurerm_key_vault.platform.public_network_access_enabled
    error_message = "Vault must be private with RBAC and purge protection."
  }
  assert {
    condition     = length(azurerm_private_endpoint.this) == 2 && length(azurerm_private_dns_zone.this) == 2 && length(azurerm_private_dns_zone_virtual_network_link.this) == 2
    error_message = "Both services need private endpoints, zones and links."
  }
  assert {
    condition     = azurerm_private_dns_zone.this["blob"].name == "privatelink.blob.core.usgovcloudapi.net" && azurerm_private_dns_zone.this["vault"].name == "privatelink.vaultcore.usgovcloudapi.net"
    error_message = "Government DNS suffixes required."
  }
  assert {
    condition     = azurerm_management_lock.state.lock_level == "CanNotDelete" && azurerm_management_lock.platform.lock_level == "CanNotDelete"
    error_message = "Both RGs require deletion locks."
  }
  assert {
    condition     = alltrue([for r in azurerm_role_assignment.secrets_officer : r.role_definition_name == "Key Vault Secrets Officer"]) && alltrue([for r in azurerm_role_assignment.state_access : r.role_definition_name == "Storage Blob Data Contributor"])
    error_message = "Expected scoped RBAC assignments."
  }
  assert {
    condition     = output.backend_config.key == "foundation/sandbox.terraform.tfstate" && output.backend_config.environment == "usgovernment" && output.backend_config.use_azuread_auth
    error_message = "Backend must use Government cloud and Entra authentication with an environment-specific key."
  }
  assert {
    condition     = azurerm_storage_account.state.tags["story"] == "STR-440" && azurerm_key_vault.platform.tags["environment"] == "sandbox"
    error_message = "Mandatory tags missing."
  }
}
run "history_and_multiple_vnets" {
  command = plan
  variables {
    virtual_network_ids = {
      endpoint = "/subscriptions/00000000-0000-0000-0000-000000000001/resourceGroups/network/providers/Microsoft.Network/virtualNetworks/endpoint"
      runner   = "/subscriptions/00000000-0000-0000-0000-000000000001/resourceGroups/network/providers/Microsoft.Network/virtualNetworks/runner"
    }
  }
  assert {
    condition     = length(azurerm_private_dns_zone_virtual_network_link.this) == 4
    error_message = "Each VNet must link to both zones."
  }
  assert {
    condition     = length(azurerm_storage_management_policy.history.rule[0].actions[0].base_blob) == 0 && azurerm_storage_management_policy.history.rule[0].actions[0].version[0].delete_after_days_since_creation == 90 && azurerm_storage_management_policy.history.rule[0].actions[0].snapshot[0].delete_after_days_since_creation_greater_than == 90
    error_message = "Only historical versions and snapshots should expire, after 90 days."
  }
}
run "reject_incomplete_containers" {
  command = plan
  variables { container_names = ["tfstate"] }
  expect_failures = [var.container_names]
}
run "reject_short_retention" {
  command = plan
  variables { history_retention_days = 30 }
  expect_failures = [var.history_retention_days]
}
run "reject_missing_tags" {
  command = plan
  variables { tags = {} }
  expect_failures = [var.tags]
}
