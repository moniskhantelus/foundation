# STR-440 — Azure Government foundation

Reviewable Terraform source for sandbox and dev. **Nothing in this package has been deployed.** Uses native AzureRM resources until approved Boeing module source URLs and immutable release tags are supplied. No module URLs, organization IDs or credentials have been invented.

## Story availability and assumptions

The requested upload `/mnt/data/Pasted markdown(3).md` was not available to this session. Implementation follows the explicit request; full story acceptance cannot be claimed until that file is reviewed. See [requirements and decisions](docs/requirements.md). Container names and business tag keys are proposed defaults, not verified story values.

## Layout

- `modules/foundation`: shared native AzureRM implementation and mock provider tests.
- `environments/sandbox`, `environments/dev`: independent root modules, provider configs, lock files, tfvars templates and state directories. Do not use Terraform workspaces to switch environments.
- `scripts/backend.py`: local-to-remote migration and remote backend initialization.
- `scripts/validate.sh`: formatting, schema validation, mock tests and plan guard tests.
- `.gitlab-ci.yml`: validation, protected branch remote plan, manual apply of saved plan.
- `docs/bootstrap.md`: prerequisites, bootstrap, migration, recovery and teardown.
- `docs/validation.md`: exact checks and optional Azure acceptance checks.

## Resources per environment

Two resource groups: state and platform. One Standard StorageV2 GZRS account with TLS 1.2, HTTPS, Entra authentication, no shared keys or public access, blob versioning and 30-day blob/container soft delete. Exactly five private containers; defaults: `tfstate`, `artifacts`, `logs`, `backups`, `bootstrap`. One lifecycle policy removes old versions/snapshots after 90 days (configurable >=31); it never deletes or tiers current blobs. No immutability policy, legal hold or WORM is configured.

One private Standard platform Key Vault with RBAC, 90-day soft delete and purge protection. Secrets Officer access is assigned to supplied Entra object IDs. No secrets are created, read or output. Backend identities get Storage Blob Data Contributor at the `tfstate` container only.

Blob and vault private endpoints use an existing subnet. Two Azure Government private DNS zones and links for every supplied VNet are created in the platform RG. CanNotDelete locks on both RGs inherit to children. All taggable resources receive business tags plus enforced environment, managed_by and story tags. Containers, policies and role assignments do not support arbitrary Azure tags.

## Quick validation (no Azure credentials or deployment)

```bash
bash scripts/validate.sh
```

Requires Terraform >=1.14,<2, Python3, Bash and access to registry.terraform.io / HashiCorp provider releases (or an approved provider mirror). Committed provider lock files select AzureRM 4.81.0. Provider upgrades require review and rerunning tests. See [recorded test results](docs/test-results.md).

## First deployment

Follow [bootstrap.md](docs/bootstrap.md) in order. Start with local state in the selected environment directory, create the foundation using a reviewed saved plan, then migrate that **same** state to its private backend. A fresh root has no backend block; never create one before the local bootstrap apply. Run each environment independently.

```bash
cp environments/sandbox/environment.tfvars.example environments/sandbox/environment.tfvars
# Fill every REPLACE_* value; arrange network access and authenticate first.
terraform -chdir=environments/sandbox init
terraform -chdir=environments/sandbox plan -var-file=environment.tfvars -out=bootstrap.tfplan
terraform -chdir=environments/sandbox apply bootstrap.tfplan
python3 scripts/backend.py sandbox migrate
terraform -chdir=environments/sandbox plan -var-file=environment.tfvars
```

Terraform is authoritative for migration; the helper does not copy/edit state. Keep local backups protected until backend verification is complete. See the recovery procedure if interrupted. Do not commit tfvars, state, plans, backend metadata or credentials.

## GitLab setup after bootstrap

1. Replace `@foundation-maintainers` in CODEOWNERS with the actual GitLab group. Enable required Code Owner approval and protected default branch/environment approvals according to the GitLab edition and team policy. The file alone does not enforce approval.
2. Configure `TF_CI_IMAGE` with an approved digest-pinned image containing Terraform, Python3 and Bash. Set up the `azure-government-private` runner with private routing and DNS. The image and runner are integration inputs.
3. Configure an Entra federated identity for GitLab's issuer and the protected branch subject, with the `api://AzureADTokenExchangeUSGov` audience matching the CI token. Confirm federation in the target Government tenant. No client secret is needed. Scope roles as described in bootstrap.md.
4. Configure environment-scoped `ARM_SUBSCRIPTION_ID`, `ARM_TENANT_ID`, `ARM_CLIENT_ID`, `STATE_RESOURCE_GROUP`, `STATE_STORAGE_ACCOUNT` and `TFVARS_FILE` (GitLab file variable containing completed environment tfvars). Scope/protect these to trusted branch runs. IDs are configuration, not secrets; never place credentials in tfvars.
5. Run a default-branch pipeline with `DEPLOY_ENV=sandbox` or `dev`. Only validation runs without this selection. Plan must pass, then an authorized maintainer starts manual apply within the one-hour artifact lifetime. Protect both deployment environments. Restrict pipeline variables so callers cannot override scoped configuration.

State storage must already exist; CI deliberately does not bootstrap or migrate. The plan and apply jobs are serialized per environment. Terraform's blob lease prevents concurrent state writes. A competing change between plan and apply causes a stale saved plan failure; rerun plan. Plan artifacts may contain sensitive information: restricted access, short lifetime, no JSON plan artifacts, no untrusted merge request cloud jobs. Confirm `artifacts:access:maintainer` support on the target GitLab version before use.

## Module integration later

See [module migration](docs/module-integration.md). Avoid replacing live resources merely to adopt approved modules. Review moved/import mapping, require no deletes/replacements, and preserve backend addresses and protective settings.

## References checked

- [AzureRM backend authentication and migration configuration](https://developer.hashicorp.com/terraform/language/backend/azurerm)
- [Azure Government private endpoint DNS suffixes](https://learn.microsoft.com/en-us/azure/private-link/private-endpoint-dns)
- [AzureRM provider source](https://github.com/hashicorp/terraform-provider-azurerm)

These document the selected approach, not Boeing approval or actual Azure deployment.
